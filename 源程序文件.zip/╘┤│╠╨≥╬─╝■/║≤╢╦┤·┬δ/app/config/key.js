module.exports = {
	secret:'register-rule'//自定义加密规则
}