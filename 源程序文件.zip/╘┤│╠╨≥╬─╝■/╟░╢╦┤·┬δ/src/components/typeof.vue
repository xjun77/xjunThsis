<template>
	<h1>typeof page</h1>
</template>

<script>
</script>

<style>
</style>
