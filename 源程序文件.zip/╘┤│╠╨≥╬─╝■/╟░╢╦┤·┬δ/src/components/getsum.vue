<template>
	<h1>hello getsum</h1>
</template>

<script>
</script>

<style>
</style>
